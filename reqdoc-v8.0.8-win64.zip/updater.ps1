# ReqDoc Studio V8 only. No legacy migration and no access to user workspace files.
param(
  [Parameter(Mandatory=$true)][string]$InstallDir,
  [Parameter(Mandatory=$true)][Alias('PackagePath')][string]$Package,
  [Parameter(Mandatory=$true)][int]$AppPid,
  [Parameter(Mandatory=$true)][string]$Sha256
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$root = Join-Path $env:LOCALAPPDATA 'ReqDocStudio'
$logDir = Join-Path $root 'logs'
$backupRoot = Join-Path $root 'program-backups'
New-Item -ItemType Directory -Path $logDir,$backupRoot -Force | Out-Null
$log = Join-Path $logDir ('update-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.log')
function WriteLog([string]$message) { (Get-Date -Format 's')+' '+$message | Out-File -LiteralPath $log -Encoding UTF8 -Append }

function WaitForProgramExit([string]$exe) {
  $timer = [Diagnostics.Stopwatch]::StartNew()
  $name = [IO.Path]::GetFileNameWithoutExtension($exe)
  $reported = $false
  while (Get-Process -Name $name -ErrorAction SilentlyContinue | Where-Object { $_.Path -ieq $exe }) {
    if ($timer.Elapsed.TotalSeconds -ge 25) { throw 'ReqDoc Studio processes in the target installation are still running' }
    if (-not $reported) {
      WriteLog ('Waiting for Windows to release '+[IO.Path]::GetFileName($exe))
      $reported = $true
    }
    Start-Sleep -Milliseconds 250
  }
}

function ReplaceProgramFile([string]$source, [string]$target) {
  $timer = [Diagnostics.Stopwatch]::StartNew()
  $reported = $false
  while ($true) {
    try {
      [IO.File]::Replace($source, $target, [NullString]::Value)
      return
    } catch {
      $code = $_.Exception.GetBaseException().HResult -band 0xFFFF
      if ($code -notin @(32, 33, 1224) -or $timer.Elapsed.TotalSeconds -ge 25) { throw }
      if (-not $reported) {
        WriteLog ('Waiting for Windows to release '+[IO.Path]::GetFileName($target))
        $reported = $true
      }
      Start-Sleep -Milliseconds 250
    }
  }
}

$expected = @('ReqDocStudio.exe','updater.ps1','version.json')
$work = Join-Path $env:TEMP ('reqdoc-v8-stage-'+[guid]::NewGuid().ToString('N'))
$stage = Join-Path $work 'stage'
$backup = Join-Path $backupRoot (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
$installed = New-Object 'System.Collections.Generic.List[string]'
$replacement = @{}
try {
  $InstallDir=[IO.Path]::GetFullPath($InstallDir)
  $Package=[IO.Path]::GetFullPath($Package)
  if (-not (Test-Path -LiteralPath (Join-Path $InstallDir 'ReqDocStudio.exe') -PathType Leaf)) {
    throw 'Not a V8 installation directory'
  }
  if (-not (Test-Path -LiteralPath $Package -PathType Leaf)) { throw 'Update package missing' }
  $actual = (Get-FileHash -LiteralPath $Package -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $Sha256.ToLowerInvariant()) { throw 'ZIP SHA256 mismatch' }

  # Wait briefly for a clean close. If a legacy Tk callback leaves the
  # old app's fatal dialog open, stop only the PID launched by this updater.
  # The app has already saved and backed up data after explicit user confirmation.
  for ($i=0; $i -lt 16; $i++) {
    if (-not (Get-Process -Id $AppPid -ErrorAction SilentlyContinue)) { break }
    Start-Sleep -Milliseconds 500
  }
  $oldProcess = Get-Process -Id $AppPid -ErrorAction SilentlyContinue
  if ($oldProcess) {
    if ($oldProcess.ProcessName -cne 'ReqDocStudio') {
      throw 'Update PID no longer belongs to ReqDoc Studio; refusing to stop another process'
    }
    $processInfo = Get-CimInstance -ClassName Win32_Process -Filter "ProcessId = $AppPid" -ErrorAction SilentlyContinue
    if ($processInfo -and $processInfo.ExecutablePath) {
      $expectedExe = [IO.Path]::GetFullPath((Join-Path $InstallDir 'ReqDocStudio.exe'))
      $actualExe = [IO.Path]::GetFullPath($processInfo.ExecutablePath)
      if ($actualExe -ine $expectedExe) {
        throw 'Update PID belongs to a different installation; refusing to stop it'
      }
    }
    WriteLog 'Legacy app did not close cleanly; stopping only the confirmed ReqDocStudio PID after data backup'
    Stop-Process -Id $AppPid -Force
    for ($i=0; $i -lt 20; $i++) {
      if (-not (Get-Process -Id $AppPid -ErrorAction SilentlyContinue)) { break }
      Start-Sleep -Milliseconds 250
    }
  }
  if (Get-Process -Id $AppPid -ErrorAction SilentlyContinue) { throw 'ReqDoc Studio process could not be stopped' }

  New-Item -ItemType Directory -Path $stage,$backup -Force | Out-Null
  $archive = [IO.Compression.ZipFile]::OpenRead($Package)
  try {
    if ($archive.Entries.Count -ne $expected.Count) { throw 'Unexpected ZIP file count' }
    $seen = @{}
    foreach ($item in $archive.Entries) {
      $entryName = $item.FullName
      if ($expected -cnotcontains $entryName -or $seen.ContainsKey($entryName)) {
        throw ('Unexpected ZIP entry: '+$entryName)
      }
      if ($item.Length -gt 300MB) { throw 'Update item too large' }
      $seen[$entryName]=$true
    }
    foreach ($name in $expected) { if (-not $seen.ContainsKey($name)) { throw ('Missing update item '+$name) } }
    foreach ($item in $archive.Entries) {
      [IO.Compression.ZipFileExtensions]::ExtractToFile($item,(Join-Path $stage $item.FullName),$false)
    }
  } finally { $archive.Dispose() }
  $meta = Get-Content -LiteralPath (Join-Path $stage 'version.json') -Raw | ConvertFrom-Json
  if ($meta.name -cne 'ReqDocStudio' -or $meta.version -notmatch '^8\.\d+\.\d+$') {
    throw 'Invalid V8 product or version metadata'
  }
  foreach ($name in $expected) {
    $target = Join-Path $InstallDir $name
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw ('Existing target missing: '+$name) }
    $info = Get-Item -LiteralPath $target -Force
    if (($info.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Link target denied' }
    Copy-Item -LiteralPath $target -Destination (Join-Path $backup $name) -Force
    # ReplaceFile requires the staged file and destination on the same volume.
    $replacement[$name] = Join-Path $InstallDir ('.'+$name+'.'+[guid]::NewGuid().ToString('N')+'.update')
    Copy-Item -LiteralPath (Join-Path $stage $name) -Destination $replacement[$name]
  }
  # PyInstaller has a parent process in addition to the Python AppPid.
  WaitForProgramExit (Join-Path $InstallDir 'ReqDocStudio.exe')
  foreach ($name in $expected) {
    ReplaceProgramFile $replacement[$name] (Join-Path $InstallDir $name)
    $installed.Add($name)
  }
  $app = Start-Process -FilePath (Join-Path $InstallDir 'ReqDocStudio.exe') -WorkingDirectory $InstallDir -PassThru
  Start-Sleep -Seconds 4
  if ($app.HasExited) { throw 'New version exited immediately' }
  WriteLog ('Installed '+$meta.version+'; program rollback backup='+$backup)
} catch {
  WriteLog ('ERROR: '+$_.Exception.Message)
  if ($installed.Count) {
    foreach ($name in $installed) {
      $previous = Join-Path $backup $name
      try {
        Copy-Item -LiteralPath $previous -Destination $replacement[$name]
        ReplaceProgramFile $replacement[$name] (Join-Path $InstallDir $name)
      } catch { WriteLog ('ROLLBACK FAILURE: '+$name) }
    }
    WriteLog 'Rollback attempted; old program files preserved in backup directory'
  }
  try {
    if (-not (Get-Process -Name 'ReqDocStudio' -ErrorAction SilentlyContinue)) {
      Start-Process -FilePath (Join-Path $InstallDir 'ReqDocStudio.exe') -WorkingDirectory $InstallDir
    }
  } catch { WriteLog ('Restart failure: '+$_.Exception.Message) }
  exit 1
} finally {
  foreach ($name in $expected) {
    if ($replacement[$name]) { Remove-Item -LiteralPath $replacement[$name] -Force -ErrorAction SilentlyContinue }
    Remove-Item -LiteralPath (Join-Path $stage $name) -Force -ErrorAction SilentlyContinue
  }
  foreach ($dir in @($stage, $work)) {
    if (Test-Path -LiteralPath $dir -PathType Container) {
      Remove-Item -LiteralPath $dir -Force -ErrorAction SilentlyContinue
    }
  }
}
